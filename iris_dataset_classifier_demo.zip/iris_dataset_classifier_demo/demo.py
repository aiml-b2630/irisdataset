"""
Automated Hackathon Demo and Verification Script.
Seeds sample data, runs validations, generates plots, exports reports, and tests persistence.
"""

import os
import sys
import time

# Ensure root directory is in python path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from src.classifier import IrisClassifierEngine
from src.storage import StorageEngine
from src.validator import validate_iris_features, ValidationError
from src.analytics import AnalyticsEngine
from src.visualizer import VisualizerEngine
from src.exporter import SummaryExporter

def run_hackathon_demo():
    print("=" * 75)
    print("  \033[1;36mIRIS DATASET CLASSIFIER DEMO - AUTOMATED SUITE\033[0m")
    print("  \033[90mHackathon Project #117: Everyday Innovators Demo\033[0m")
    print("=" * 75)
    
    # Step 1: Initialize Engine and Train Model
    print("\n[Step 1/6] Initializing Scikit-Learn Classifier Engine...")
    classifier = IrisClassifierEngine(random_state=42)
    print(f"  \033[92m[OK]\033[0m Model Trained. Test Accuracy: {classifier.accuracy * 100:.2f}%")
    
    # Step 2: Storage Setup & Seeding Sample Records
    print("\n[Step 2/6] Initializing Persistence Layer & Seeding Sample Dataset...")
    storage = StorageEngine()
    storage.clear_records()  # Fresh start for demo
    
    sample_inputs = [
        # Setosa examples
        {"sepal_length": 5.1, "sepal_width": 3.5, "petal_length": 1.4, "petal_width": 0.2, "notes": "Seed Setosa 1"},
        {"sepal_length": 4.9, "sepal_width": 3.0, "petal_length": 1.4, "petal_width": 0.2, "notes": "Seed Setosa 2"},
        {"sepal_length": 4.7, "sepal_width": 3.2, "petal_length": 1.3, "petal_width": 0.2, "notes": "Seed Setosa 3"},
        # Versicolor examples
        {"sepal_length": 6.4, "sepal_width": 3.2, "petal_length": 4.5, "petal_width": 1.5, "notes": "Seed Versicolor 1"},
        {"sepal_length": 5.5, "sepal_width": 2.3, "petal_length": 4.0, "petal_width": 1.3, "notes": "Seed Versicolor 2"},
        {"sepal_length": 6.5, "sepal_width": 2.8, "petal_length": 4.6, "petal_width": 1.5, "notes": "Seed Versicolor 3"},
        # Virginica examples
        {"sepal_length": 6.3, "sepal_width": 3.3, "petal_length": 6.0, "petal_width": 2.5, "notes": "Seed Virginica 1"},
        {"sepal_length": 7.2, "sepal_width": 3.6, "petal_length": 6.1, "petal_width": 2.5, "notes": "Seed Virginica 2"},
        {"sepal_length": 6.9, "sepal_width": 3.1, "petal_length": 5.4, "petal_width": 2.1, "notes": "Seed Virginica 3"},
    ]
    
    for item in sample_inputs:
        validated = validate_iris_features(
            item["sepal_length"], item["sepal_width"], 
            item["petal_length"], item["petal_width"]
        )
        pred = classifier.predict(validated)
        rec = storage.save_record(validated, pred, notes=item["notes"])
        print(f"  \033[94m+ Saved Record [{rec['record_id']}]:\033[0m {rec['predicted_species'].upper()} (Confidence: {rec['confidence']*100:.1f}%)")
        
    records = storage.load_all_records()
    print(f"  \033[92m[OK]\033[0m Total Seed Records Logged: {len(records)}")

    # Step 3: Demonstrating Input Validation Engine
    print("\n[Step 3/6] Testing Defensive Input Validation Engine...")
    test_cases = [
        {"input": (12.0, 3.5, 1.4, 0.2), "desc": "Sepal length 12.0cm (Out of bounds)"},
        {"input": (5.1, "abc", 1.4, 0.2), "desc": "Non-numeric Sepal width 'abc'"},
        {"input": (5.1, 3.5, -1.0, 0.2), "desc": "Negative Petal length -1.0cm"}
    ]
    for tc in test_cases:
        try:
            validate_iris_features(*tc["input"])
            print(f"  \033[91m[FAIL]\033[0m Expected error for {tc['desc']}")
        except ValidationError as e:
            err_msg = str(e).splitlines()[0]
            print(f"  \033[92m[PASS]\033[0m Defensive Catch for '{tc['desc']}':\n         -> {err_msg}")

    # Step 4: Analytics Aggregation
    print("\n[Step 4/6] Computing Executive Analytics & Summary Aggregations...")
    stats = AnalyticsEngine.compute_summary_statistics(records)
    print(f"  Total Records  : {stats['total_records']}")
    print(f"  Avg Confidence : {stats['average_confidence']*100:.2f}%")
    print(f"  Species Counts : {stats['species_counts']}")

    # Step 5: Visual Data Plotting
    print("\n[Step 5/6] Generating Matplotlib Trend Charts & Visual Plots...")
    viz = VisualizerEngine(output_dir="exports")
    p1 = viz.plot_species_distribution(records, filename="species_distribution.png")
    p2 = viz.plot_petal_scatter(records, filename="petal_scatter.png")
    p3 = viz.plot_feature_importance(classifier.get_feature_importances(), filename="feature_importance.png")
    print(f"  \033[92m[OK]\033[0m Visual plots saved to 'exports/' directory:")
    print(f"       1. {p1}\n       2. {p2}\n       3. {p3}")

    # Step 6: Multi-Format Reports Export
    print("\n[Step 6/6] Exporting Multi-Format Audit Reports...")
    exporter = SummaryExporter(export_dir="exports")
    r1 = exporter.export_markdown_report(stats, records, filename="iris_summary_report.md")
    r2 = exporter.export_audit_log_txt(records, filename="audit_log.txt")
    print(f"  \033[92m[OK]\033[0m Summary reports created:")
    print(f"       1. Markdown Report : {r1}")
    print(f"       2. Audit Text Log  : {r2}")

    print("\n" + "=" * 75)
    print("  \033[1;32mSUCCESS: All 6 Demo Milestones Completed Flawlessly!\033[0m")
    print("=" * 75)

if __name__ == "__main__":
    run_hackathon_demo()
