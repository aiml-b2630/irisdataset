# Iris Dataset Classifier Demo (`iris_classifier_demo`)
> **Problem Brief #117: Everyday Innovators Prototype**  
> *Domain: AI, APIs & Smart Applications | Hackathon Mentor Guide Project*

---

## 🌟 Overview & Architecture

The **Iris Dataset Classifier Demo** is a modular, production-ready Python prototype designed to streamline scikit-learn machine learning workflows on the Iris dataset. It provides strict input sanitization, automated local file persistence (JSON & CSV), executive statistical analytics, Matplotlib visual data plotting, and multi-format report exports (Markdown, TXT, CSV).

### 🏗️ Project Directory Layout

```
iris_dataset_classifier_demo/
├── README.md                   # Project documentation & usage guide
├── requirements.txt            # Python dependencies
├── main.py                     # Interactive ANSI CLI menu dispatch loop
├── demo.py                     # Non-interactive automated hackathon demo script
├── data/                       # Local data storage layer
│   ├── predictions_history.json # JSON record store with schema checks
│   └── predictions_history.csv  # Standardized CSV log
├── exports/                    # Generated charts & exported reports
│   ├── species_distribution.png
│   ├── petal_scatter.png
│   ├── feature_importance.png
│   ├── iris_summary_report.md
│   └── audit_log.txt
├── src/                        # Core backend package modules
│   ├── __init__.py
│   ├── classifier.py           # Scikit-Learn RandomForestClassifier engine
│   ├── validator.py            # Real-time sanitization & boundary checking
│   ├── storage.py              # Atomic persistence & fault-tolerant file recovery
│   ├── analytics.py            # Summary aggregation metrics & species breakdown
│   ├── visualizer.py           # Matplotlib headless plot generator
│   └── exporter.py             # Markdown report & TXT audit log builder
└── tests/                      # Comprehensive unit test suite
    ├── __init__.py
    ├── test_classifier.py
    ├── test_validator.py
    └── test_storage.py
```

---

## ✨ Must-Have & Stretch Features Implemented

1. **Defensive Input Validation Engine:** Real-time sanitization, regex stripping, and domain boundary validation (Sepal length 4.0–8.0 cm, Sepal width 2.0–4.5 cm, Petal length 1.0–7.0 cm, Petal width 0.1–2.5 cm).
2. **Core ML Workflow Engine:** Scikit-Learn `RandomForestClassifier` trained on the Iris dataset with >95% accuracy, probability confidence scoring, and feature importance analysis.
3. **Local File Persistence & Error Recovery:** Dual JSON & CSV recording. Auto-detects missing or corrupted JSON files and gracefully rebuilds clean stores with backups.
4. **Record Search & Filter:** Keyword-based filtering across record IDs, timestamp strings, species, and notes.
5. **Executive Summary Analytics:** Computes total counts, species percentage splits, average feature dimensions per species, and average confidence levels.
6. **Visual Data Plotting (Matplotlib):** Automated generation of species distribution bar plots, petal scatter plots, and feature importance horizonal bar charts.
7. **Multi-Format Summary Export:** Standardized Markdown (`.md`) reports, plain-text audit logs (`.txt`), and CSV spreadsheets.

---

## 🚀 Quick Start Guide

### 1. Prerequisites & Installation

Ensure you have Python 3.10+ installed.

```bash
# Clone or unzip project files
cd iris_dataset_classifier_demo

# Install required packages
pip install -r requirements.txt
```

### 2. Running the Interactive CLI Menu

```bash
python main.py
```

### 3. Running the Automated Hackathon Demo Suite

```bash
python demo.py
```

### 4. Running Unit Tests

```bash
python -m unittest discover -s tests
```

---

## 📊 Sample Dataset Schema

Each prediction record is saved in JSON format as follows:

```json
{
  "record_id": "REC-0001",
  "timestamp": "2026-11-20 20:30:00",
  "sepal_length": 5.1,
  "sepal_width": 3.5,
  "petal_length": 1.4,
  "petal_width": 0.2,
  "predicted_species": "setosa",
  "confidence": 0.99,
  "probabilities": {
    "setosa": 0.99,
    "versicolor": 0.01,
    "virginica": 0.0
  },
  "notes": "Sample entry"
}
```

---

## 🛡️ License & Acknowledgments

Developed as an open-source prototype for **Problem Brief #117: Everyday Innovators Hackathon**. Grounded in `scikit-learn`, `matplotlib`, `pandas`, and `numpy`.
