# Iris Dataset Classifier Demo - Executive Summary Report
**Generated:** 2026-11-21 04:32:24

---
## 1. High-Level Performance Metrics
- **Total Records Processed:** 9
- **Average Model Confidence:** 99.44%

### Prediction Breakdown by Species
| Species | Count | Percentage |
| :--- | :---: | :---: |
| **Setosa** | 3 | 33.3% |
| **Versicolor** | 3 | 33.3% |
| **Virginica** | 3 | 33.3% |

## 2. Species Feature Averages (cm)
| Species | Sepal Length | Sepal Width | Petal Length | Petal Width | Avg Confidence |
| :--- | :---: | :---: | :---: | :---: | :---: |
| **Setosa** | 4.90 | 3.23 | 1.37 | 0.20 | 100.0% |
| **Versicolor** | 6.13 | 2.77 | 4.37 | 1.43 | 98.3% |
| **Virginica** | 6.80 | 3.33 | 5.83 | 2.37 | 100.0% |

## 3. Recent Prediction Audit Logs
| Record ID | Timestamp | Sepal L/W | Petal L/W | Predicted Species | Confidence |
| :--- | :--- | :--- | :--- | :--- | :---: |
| `REC-0001` | 2026-11-21 04:32:23 | 5.1/3.5 | 1.4/0.2 | **Setosa** | 100.0% |
| `REC-0002` | 2026-11-21 04:32:23 | 4.9/3.0 | 1.4/0.2 | **Setosa** | 100.0% |
| `REC-0003` | 2026-11-21 04:32:23 | 4.7/3.2 | 1.3/0.2 | **Setosa** | 100.0% |
| `REC-0004` | 2026-11-21 04:32:23 | 6.4/3.2 | 4.5/1.5 | **Versicolor** | 98.0% |
| `REC-0005` | 2026-11-21 04:32:23 | 5.5/2.3 | 4.0/1.3 | **Versicolor** | 100.0% |
| `REC-0006` | 2026-11-21 04:32:23 | 6.5/2.8 | 4.6/1.5 | **Versicolor** | 97.0% |
| `REC-0007` | 2026-11-21 04:32:23 | 6.3/3.3 | 6.0/2.5 | **Virginica** | 100.0% |
| `REC-0008` | 2026-11-21 04:32:23 | 7.2/3.6 | 6.1/2.5 | **Virginica** | 100.0% |
| `REC-0009` | 2026-11-21 04:32:23 | 6.9/3.1 | 5.4/2.1 | **Virginica** | 100.0% |

---
*Report generated automatically by Iris Dataset Classifier Demo Engine.*