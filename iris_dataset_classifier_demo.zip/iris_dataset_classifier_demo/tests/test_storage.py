"""
Unit Tests for Local Storage and Persistence Engine.
"""

import os
import shutil
import unittest
from src.storage import StorageEngine

class TestStorage(unittest.TestCase):

    def setUp(self):
        self.test_dir = "test_data_temp"
        self.json_path = os.path.join(self.test_dir, "test_pred.json")
        self.csv_path = os.path.join(self.test_dir, "test_pred.csv")
        self.storage = StorageEngine(json_path=self.json_path, csv_path=self.csv_path)

    def tearDown(self):
        if os.path.exists(self.test_dir):
            shutil.rmtree(self.test_dir)

    def test_save_and_load_record(self):
        features = {"sepal_length": 5.1, "sepal_width": 3.5, "petal_length": 1.4, "petal_width": 0.2}
        prediction = {
            "predicted_species": "setosa",
            "confidence": 0.99,
            "probabilities": {"setosa": 0.99, "versicolor": 0.01, "virginica": 0.0}
        }
        rec = self.storage.save_record(features, prediction, notes="Test record")
        self.assertEqual(rec["record_id"], "REC-0001")
        
        loaded = self.storage.load_all_records()
        self.assertEqual(len(loaded), 1)
        self.assertEqual(loaded[0]["predicted_species"], "setosa")

    def test_search_records(self):
        features = {"sepal_length": 6.0, "sepal_width": 2.8, "petal_length": 4.5, "petal_width": 1.4}
        prediction = {
            "predicted_species": "versicolor",
            "confidence": 0.92,
            "probabilities": {"setosa": 0.0, "versicolor": 0.92, "virginica": 0.08}
        }
        self.storage.save_record(features, prediction, notes="Special versicolor sample")
        
        results = self.storage.search_records(query="Special")
        self.assertEqual(len(results), 1)
        self.assertEqual(results[0]["predicted_species"], "versicolor")

if __name__ == "__main__":
    unittest.main()
