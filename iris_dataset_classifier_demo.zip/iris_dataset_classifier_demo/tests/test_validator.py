"""
Unit Tests for Input Validation Engine.
"""

import unittest
from src.validator import (
    validate_iris_features,
    sanitize_and_parse_float,
    ValidationError
)

class TestValidator(unittest.TestCase):

    def test_valid_inputs(self):
        res = validate_iris_features("5.1 cm", "3.5", 1.4, 0.2)
        self.assertEqual(res["sepal_length"], 5.1)
        self.assertEqual(res["sepal_width"], 3.5)
        self.assertEqual(res["petal_length"], 1.4)
        self.assertEqual(res["petal_width"], 0.2)

    def test_out_of_bounds_input(self):
        with self.assertRaises(ValidationError):
            validate_iris_features(15.0, 3.5, 1.4, 0.2)  # Sepal length out of range

    def test_non_numeric_input(self):
        with self.assertRaises(ValidationError):
            sanitize_and_parse_float("abc", "Sepal Length")

if __name__ == "__main__":
    unittest.main()
