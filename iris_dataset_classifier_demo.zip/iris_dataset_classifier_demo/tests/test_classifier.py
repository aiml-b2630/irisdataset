"""
Unit Tests for Scikit-Learn Classifier Engine.
"""

import unittest
from src.classifier import IrisClassifierEngine

class TestClassifier(unittest.TestCase):

    def setUp(self):
        self.engine = IrisClassifierEngine(random_state=42)

    def test_training_accuracy(self):
        self.assertTrue(self.engine.is_trained)
        self.assertGreaterEqual(self.engine.accuracy, 0.90)

    def test_prediction_setosa(self):
        # Known setosa measurements: 5.1, 3.5, 1.4, 0.2
        features = {
            "sepal_length": 5.1,
            "sepal_width": 3.5,
            "petal_length": 1.4,
            "petal_width": 0.2
        }
        pred = self.engine.predict(features)
        self.assertEqual(pred["predicted_species"], "setosa")
        self.assertGreater(pred["confidence"], 0.8)

    def test_prediction_virginica(self):
        # Known virginica measurements: 6.7, 3.0, 5.2, 2.3
        features = {
            "sepal_length": 6.7,
            "sepal_width": 3.0,
            "petal_length": 5.2,
            "petal_width": 2.3
        }
        pred = self.engine.predict(features)
        self.assertEqual(pred["predicted_species"], "virginica")

if __name__ == "__main__":
    unittest.main()
