"""
Multi-Format Summary Exporter for Iris Classifier Demo.
Generates structured Markdown reports, plain-text audit logs, and standardized CSV exports.
"""

import os
import csv
import datetime
from typing import List, Dict, Any

class SummaryExporter:
    """
    Exports analytics summaries and prediction history into Markdown, TXT, and CSV formats.
    """

    def __init__(self, export_dir: str = "exports"):
        self.export_dir = export_dir
        os.makedirs(self.export_dir, exist_ok=True)

    def export_markdown_report(self, summary_stats: Dict[str, Any], records: List[Dict[str, Any]], filename: str = "iris_summary_report.md") -> str:
        """
        Generates a comprehensive executive summary in Markdown format.
        """
        filepath = os.path.join(self.export_dir, filename)
        now_str = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        
        md_content = []
        md_content.append("# Iris Dataset Classifier Demo - Executive Summary Report")
        md_content.append(f"**Generated:** {now_str}\n")
        md_content.append("---")
        
        md_content.append("## 1. High-Level Performance Metrics")
        md_content.append(f"- **Total Records Processed:** {summary_stats['total_records']}")
        md_content.append(f"- **Average Model Confidence:** {summary_stats['average_confidence'] * 100:.2f}%\n")
        
        md_content.append("### Prediction Breakdown by Species")
        md_content.append("| Species | Count | Percentage |")
        md_content.append("| :--- | :---: | :---: |")
        for sp, count in summary_stats["species_counts"].items():
            pct = summary_stats["species_percentages"].get(sp, 0.0)
            md_content.append(f"| **{sp.capitalize()}** | {count} | {pct:.1f}% |")
        md_content.append("")
        
        md_content.append("## 2. Species Feature Averages (cm)")
        md_content.append("| Species | Sepal Length | Sepal Width | Petal Length | Petal Width | Avg Confidence |")
        md_content.append("| :--- | :---: | :---: | :---: | :---: | :---: |")
        for sp, avg_dict in summary_stats.get("species_feature_averages", {}).items():
            if avg_dict["count"] > 0:
                md_content.append(
                    f"| **{sp.capitalize()}** | {avg_dict['sepal_length']:.2f} | "
                    f"{avg_dict['sepal_width']:.2f} | {avg_dict['petal_length']:.2f} | "
                    f"{avg_dict['petal_width']:.2f} | {avg_dict['avg_confidence'] * 100:.1f}% |"
                )
            else:
                md_content.append(f"| **{sp.capitalize()}** | - | - | - | - | - |")
        md_content.append("")
        
        md_content.append("## 3. Recent Prediction Audit Logs")
        md_content.append("| Record ID | Timestamp | Sepal L/W | Petal L/W | Predicted Species | Confidence |")
        md_content.append("| :--- | :--- | :--- | :--- | :--- | :---: |")
        for r in records[-10:]:  # Display last 10 records
            sepal = f"{r['sepal_length']:.1f}/{r['sepal_width']:.1f}"
            petal = f"{r['petal_length']:.1f}/{r['petal_width']:.1f}"
            md_content.append(
                f"| `{r['record_id']}` | {r['timestamp']} | {sepal} | {petal} | "
                f"**{r['predicted_species'].capitalize()}** | {r['confidence']*100:.1f}% |"
            )
            
        md_content.append("\n---\n*Report generated automatically by Iris Dataset Classifier Demo Engine.*")
        
        with open(filepath, "w", encoding="utf-8") as f:
            f.write("\n".join(md_content))
            
        return filepath

    def export_audit_log_txt(self, records: List[Dict[str, Any]], filename: str = "audit_log.txt") -> str:
        """
        Generates a plain-text standardized audit log file.
        """
        filepath = os.path.join(self.export_dir, filename)
        now_str = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        
        lines = []
        lines.append("==========================================================================")
        lines.append(f"IRIS DATASET CLASSIFIER DEMO - SYSTEM AUDIT LOG")
        lines.append(f"Timestamp: {now_str}")
        lines.append(f"Total Logged Entries: {len(records)}")
        lines.append("==========================================================================\n")
        
        for r in records:
            lines.append(f"[{r['record_id']}] {r['timestamp']}")
            lines.append(f"  Inputs  : Sepal L={r['sepal_length']}cm, W={r['sepal_width']}cm | Petal L={r['petal_length']}cm, W={r['petal_width']}cm")
            lines.append(f"  Outcome : Predicted Species = '{r['predicted_species'].upper()}' (Confidence: {r['confidence']*100:.2f}%)")
            lines.append(f"  Notes   : {r.get('notes', 'N/A')}")
            lines.append("-" * 74)
            
        with open(filepath, "w", encoding="utf-8") as f:
            f.write("\n".join(lines))
            
        return filepath
