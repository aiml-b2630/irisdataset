"""
Iris Dataset Classifier Demo - Source Package
"""

__version__ = "1.0.0"
