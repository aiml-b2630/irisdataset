"""
Local File Persistence and Query Engine for Iris Classifier Demo.
Supports atomic reading/writing of prediction records in JSON and CSV formats.
Includes fault-tolerant error handling for missing or corrupted storage files.
"""

import os
import json
import csv
import datetime
from typing import List, Dict, Any, Optional

DEFAULT_JSON_PATH = os.path.join("data", "predictions_history.json")
DEFAULT_CSV_PATH = os.path.join("data", "predictions_history.csv")

class StorageEngine:
    """
    Manages structured data persistence and querying across JSON and CSV storage layers.
    """
    
    CSV_HEADERS = [
        "record_id", "timestamp", "sepal_length", "sepal_width", 
        "petal_length", "petal_width", "predicted_species", 
        "confidence", "notes"
    ]
    
    def __init__(self, json_path: str = DEFAULT_JSON_PATH, csv_path: str = DEFAULT_CSV_PATH):
        self.json_path = json_path
        self.csv_path = csv_path
        self._ensure_data_files_exist()

    def _ensure_data_files_exist(self) -> None:
        """
        Guarantees that directories and file paths exist.
        Recovers gracefully if files are missing or corrupted.
        """
        for filepath in [self.json_path, self.csv_path]:
            dirname = os.path.dirname(filepath)
            if dirname and not os.path.exists(dirname):
                os.makedirs(dirname, exist_ok=True)
                
        # Check or initialize JSON file
        if not os.path.exists(self.json_path) or os.path.getsize(self.json_path) == 0:
            self._write_json([])
        else:
            # Verify JSON integrity
            try:
                with open(self.json_path, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    if not isinstance(data, list):
                        self._write_json([])
            except (json.JSONDecodeError, OSError):
                # Auto-recovery for corrupted JSON
                backup_name = f"{self.json_path}.corrupted_{int(datetime.datetime.now().timestamp())}"
                if os.path.exists(self.json_path):
                    os.rename(self.json_path, backup_name)
                self._write_json([])

        # Check or initialize CSV file
        if not os.path.exists(self.csv_path) or os.path.getsize(self.csv_path) == 0:
            self._init_csv_header()

    def _init_csv_header(self) -> None:
        """Initializes CSV file with standard headers."""
        with open(self.csv_path, "w", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            writer.writerow(self.CSV_HEADERS)

    def _write_json(self, records: List[Dict[str, Any]]) -> None:
        """Helper to write records cleanly to JSON."""
        with open(self.json_path, "w", encoding="utf-8") as f:
            json.dump(records, f, indent=2, ensure_ascii=False)

    def load_all_records(self) -> List[Dict[str, Any]]:
        """Reads all saved prediction records from JSON storage."""
        try:
            with open(self.json_path, "r", encoding="utf-8") as f:
                records = json.load(f)
                return records if isinstance(records, list) else []
        except (json.JSONDecodeError, FileNotFoundError):
            self._ensure_data_files_exist()
            return []

    def save_record(self, features: Dict[str, float], prediction_result: Dict[str, Any], notes: str = "") -> Dict[str, Any]:
        """
        Saves a new prediction record atomically to both JSON and CSV files.
        """
        records = self.load_all_records()
        record_id = f"REC-{len(records) + 1:04d}"
        timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        
        record = {
            "record_id": record_id,
            "timestamp": timestamp,
            "sepal_length": features["sepal_length"],
            "sepal_width": features["sepal_width"],
            "petal_length": features["petal_length"],
            "petal_width": features["petal_width"],
            "predicted_species": prediction_result["predicted_species"],
            "confidence": round(prediction_result["confidence"], 4),
            "probabilities": prediction_result["probabilities"],
            "notes": notes or "Manual Entry"
        }
        
        # Save to JSON
        records.append(record)
        self._write_json(records)
        
        # Append to CSV
        with open(self.csv_path, "a", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            writer.writerow([
                record["record_id"],
                record["timestamp"],
                record["sepal_length"],
                record["sepal_width"],
                record["petal_length"],
                record["petal_width"],
                record["predicted_species"],
                record["confidence"],
                record["notes"]
            ])
            
        return record

    def search_records(self, query: Optional[str] = None, species: Optional[str] = None) -> List[Dict[str, Any]]:
        """
        Filters stored records by search query string or specific species.
        """
        records = self.load_all_records()
        filtered = []
        
        for r in records:
            match = True
            if species and species.lower() != "all":
                if r.get("predicted_species", "").lower() != species.lower():
                    match = False
            if query and match:
                q_lower = str(query).lower()
                fields_str = " ".join([
                    str(r.get("record_id", "")),
                    str(r.get("predicted_species", "")),
                    str(r.get("notes", "")),
                    str(r.get("timestamp", ""))
                ]).lower()
                if q_lower not in fields_str:
                    match = False
            if match:
                filtered.append(r)
                
        return filtered

    def clear_records(self) -> None:
        """Clears stored prediction records."""
        self._write_json([])
        self._init_csv_header()
