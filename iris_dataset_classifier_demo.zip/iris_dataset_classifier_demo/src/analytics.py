"""
Executive Analytics and Aggregation Engine for Iris Classifier Demo.
Calculates statistical metrics, species counts, averages, and confidence trends.
"""

from typing import List, Dict, Any, Optional

class AnalyticsEngine:
    """
    Computes statistical aggregations and metrics across stored Iris prediction logs.
    """

    @staticmethod
    def compute_summary_statistics(records: List[Dict[str, Any]]) -> Dict[str, Any]:
        """
        Computes aggregate metrics from a list of record dictionaries.
        """
        total_records = len(records)
        if total_records == 0:
            return {
                "total_records": 0,
                "species_counts": {"setosa": 0, "versicolor": 0, "virginica": 0},
                "species_percentages": {"setosa": 0.0, "versicolor": 0.0, "virginica": 0.0},
                "average_confidence": 0.0,
                "overall_feature_averages": {
                    "sepal_length": 0.0, "sepal_width": 0.0,
                    "petal_length": 0.0, "petal_width": 0.0
                },
                "species_feature_averages": {}
            }

        # Initialize aggregations
        species_counts = {"setosa": 0, "versicolor": 0, "virginica": 0}
        total_conf = 0.0
        
        feature_sums = {
            "sepal_length": 0.0, "sepal_width": 0.0,
            "petal_length": 0.0, "petal_width": 0.0
        }
        
        species_groups = {
            "setosa": [], "versicolor": [], "virginica": []
        }

        for r in records:
            sp = r.get("predicted_species", "unknown").lower()
            if sp in species_counts:
                species_counts[sp] += 1
            else:
                species_counts[sp] = 1
                
            conf = float(r.get("confidence", 0.0))
            total_conf += conf
            
            for feat in feature_sums.keys():
                val = float(r.get(feat, 0.0))
                feature_sums[feat] += val
                
            if sp in species_groups:
                species_groups[sp].append(r)

        # Species percentages
        species_percentages = {
            sp: round((cnt / total_records) * 100.0, 1)
            for sp, cnt in species_counts.items()
        }

        # Overall feature averages
        overall_feature_averages = {
            feat: round(sum_val / total_records, 2)
            for feat, sum_val in feature_sums.items()
        }

        # Species-specific feature averages
        species_feature_averages = {}
        for sp, sp_records in species_groups.items():
            count = len(sp_records)
            if count > 0:
                species_feature_averages[sp] = {
                    "count": count,
                    "sepal_length": round(sum(r["sepal_length"] for r in sp_records) / count, 2),
                    "sepal_width":  round(sum(r["sepal_width"] for r in sp_records) / count, 2),
                    "petal_length": round(sum(r["petal_length"] for r in sp_records) / count, 2),
                    "petal_width":  round(sum(r["petal_width"] for r in sp_records) / count, 2),
                    "avg_confidence": round(sum(r["confidence"] for r in sp_records) / count, 3)
                }
            else:
                species_feature_averages[sp] = {
                    "count": 0, "sepal_length": 0.0, "sepal_width": 0.0,
                    "petal_length": 0.0, "petal_width": 0.0, "avg_confidence": 0.0
                }

        return {
            "total_records": total_records,
            "species_counts": species_counts,
            "species_percentages": species_percentages,
            "average_confidence": round(total_conf / total_records, 4),
            "overall_feature_averages": overall_feature_averages,
            "species_feature_averages": species_feature_averages
        }
