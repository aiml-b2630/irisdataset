"""
Visual Data Plotting Module for Iris Classifier Demo.
Integrates Matplotlib to generate distribution charts, prediction species counts,
and model feature importance plots.
"""

import os
from typing import List, Dict, Any, Optional

import matplotlib
matplotlib.use('Agg')  # Non-interactive headless backend
import matplotlib.pyplot as plt

class VisualizerEngine:
    """
    Generates and saves publication-quality Matplotlib visual plots.
    """
    
    SPECIES_COLORS = {
        "setosa": "#2b5c8f",     # Deep Blue
        "versicolor": "#d95f02", # Vivid Orange
        "virginica": "#7570b3"   # Purple
    }

    def __init__(self, output_dir: str = "exports"):
        self.output_dir = output_dir
        os.makedirs(self.output_dir, exist_ok=True)

    def plot_species_distribution(self, records: List[Dict[str, Any]], filename: str = "species_distribution.png") -> str:
        """
        Generates a bar plot showing the breakdown of predictions by Iris species.
        """
        filepath = os.path.join(self.output_dir, filename)
        counts = {"setosa": 0, "versicolor": 0, "virginica": 0}
        
        for r in records:
            sp = r.get("predicted_species", "").lower()
            if sp in counts:
                counts[sp] += 1
                
        species_list = list(counts.keys())
        val_list = [counts[sp] for sp in species_list]
        colors = [self.SPECIES_COLORS[sp] for sp in species_list]
        
        fig, ax = plt.subplots(figsize=(7, 4.5), dpi=150)
        bars = ax.bar(species_list, val_list, color=colors, width=0.5, edgecolor="black", linewidth=0.8)
        
        ax.set_title("Iris Prediction Distribution by Species", fontsize=12, fontweight="bold", pad=12)
        ax.set_xlabel("Iris Species", fontsize=10, fontweight="bold")
        ax.set_ylabel("Number of Predictions", fontsize=10, fontweight="bold")
        ax.grid(axis="y", linestyle="--", alpha=0.5)
        
        # Annotate bars
        for bar in bars:
            height = bar.get_height()
            ax.annotate(f"{height}",
                        xy=(bar.get_x() + bar.get_width() / 2, height),
                        xytext=(0, 3), textcoords="offset points",
                        ha="center", va="bottom", fontsize=10, fontweight="bold")
                        
        plt.tight_layout()
        plt.savefig(filepath)
        plt.close(fig)
        return filepath

    def plot_petal_scatter(self, records: List[Dict[str, Any]], filename: str = "petal_scatter.png") -> str:
        """
        Generates a scatter plot comparing Petal Length vs Petal Width across predicted species.
        """
        filepath = os.path.join(self.output_dir, filename)
        fig, ax = plt.subplots(figsize=(7.5, 5), dpi=150)
        
        for sp in ["setosa", "versicolor", "virginica"]:
            sp_recs = [r for r in records if r.get("predicted_species", "").lower() == sp]
            if sp_recs:
                x = [r["petal_length"] for r in sp_recs]
                y = [r["petal_width"] for r in sp_recs]
                ax.scatter(x, y, label=sp.capitalize(), color=self.SPECIES_COLORS[sp], 
                           s=60, alpha=0.8, edgecolors="black", linewidths=0.5)
                
        ax.set_title("Petal Length vs Petal Width (Prediction Logs)", fontsize=12, fontweight="bold", pad=12)
        ax.set_xlabel("Petal Length (cm)", fontsize=10, fontweight="bold")
        ax.set_ylabel("Petal Width (cm)", fontsize=10, fontweight="bold")
        ax.legend(title="Species", frameon=True)
        ax.grid(True, linestyle="--", alpha=0.4)
        
        plt.tight_layout()
        plt.savefig(filepath)
        plt.close(fig)
        return filepath

    def plot_feature_importance(self, importances: Dict[str, float], filename: str = "feature_importance.png") -> str:
        """
        Plots feature importances calculated by the Scikit-Learn model.
        """
        filepath = os.path.join(self.output_dir, filename)
        features = list(importances.keys())
        scores = [importances[f] for f in features]
        
        # Sort features by importance
        sorted_pairs = sorted(zip(features, scores), key=lambda x: x[1])
        sorted_features = [p[0].replace("_", " ").title() for p in sorted_pairs]
        sorted_scores = [p[1] for p in sorted_pairs]
        
        fig, ax = plt.subplots(figsize=(7, 4), dpi=150)
        bars = ax.barh(sorted_features, sorted_scores, color="#1b9e77", edgecolor="black", linewidth=0.8)
        
        ax.set_title("Scikit-Learn Model Feature Importance", fontsize=12, fontweight="bold", pad=12)
        ax.set_xlabel("Importance Score", fontsize=10, fontweight="bold")
        ax.set_xlim(0, max(sorted_scores) * 1.15)
        ax.grid(axis="x", linestyle="--", alpha=0.5)
        
        for bar in bars:
            width = bar.get_width()
            ax.annotate(f"{width:.3f}",
                        xy=(width, bar.get_y() + bar.get_height() / 2),
                        xytext=(5, 0), textcoords="offset points",
                        ha="left", va="center", fontsize=9, fontweight="bold")
                        
        plt.tight_layout()
        plt.savefig(filepath)
        plt.close(fig)
        return filepath
