"""
Input Validation and Sanitization Module for Iris Feature Measurements.
Ensures real-time sanitization and strict domain boundary checks.
"""

import re
from typing import Dict, Any, Tuple

# Domain constraints for Iris dataset features (in centimeters)
FEATURE_BOUNDS = {
    "sepal_length": {"min": 4.0, "max": 8.0, "label": "Sepal Length (cm)"},
    "sepal_width":  {"min": 2.0, "max": 4.5, "label": "Sepal Width (cm)"},
    "petal_length": {"min": 1.0, "max": 7.0, "label": "Petal Length (cm)"},
    "petal_width":  {"min": 0.1, "max": 2.5, "label": "Petal Width (cm)"}
}

class ValidationError(Exception):
    """Custom exception raised when feature inputs violate domain constraints."""
    pass

def sanitize_and_parse_float(raw_input: str, field_name: str) -> float:
    """
    Sanitizes string input and parses it as a float.
    Handles extra whitespace, trailing units, and non-numeric characters.
    """
    if raw_input is None or not str(raw_input).strip():
        raise ValidationError(f"[{field_name}] Input cannot be empty.")
    
    # Strip whitespace and common units like 'cm'
    cleaned = str(raw_input).strip().lower().replace("cm", "").strip()
    
    # Check for valid numeric format
    if not re.match(r"^\d+(\.\d+)?$", cleaned):
        raise ValidationError(f"[{field_name}] '{raw_input}' is not a valid positive numeric value.")
    
    try:
        val = float(cleaned)
        return val
    except ValueError:
        raise ValidationError(f"[{field_name}] Failed to parse numerical value from '{raw_input}'.")

def validate_feature_value(field_name: str, val: float) -> float:
    """
    Validates that a parsed float falls within domain boundary constraints.
    """
    bounds = FEATURE_BOUNDS.get(field_name)
    if not bounds:
        raise ValidationError(f"Unknown feature field: '{field_name}'.")
    
    if val < bounds["min"] or val > bounds["max"]:
        raise ValidationError(
            f"[{bounds['label']}] Value {val:.2f} cm is out of reasonable range "
            f"[{bounds['min']:.1f} - {bounds['max']:.1f} cm]."
        )
    return val

def validate_iris_features(sepal_length: Any, sepal_width: Any, 
                           petal_length: Any, petal_width: Any) -> Dict[str, float]:
    """
    Sanitizes and validates all four Iris feature measurements.
    Returns a dictionary of validated float values.
    """
    raw_inputs = {
        "sepal_length": sepal_length,
        "sepal_width": sepal_width,
        "petal_length": petal_length,
        "petal_width": petal_width
    }
    
    validated = {}
    errors = []
    
    for field, raw_val in raw_inputs.items():
        try:
            parsed = sanitize_and_parse_float(raw_val, FEATURE_BOUNDS[field]["label"])
            val = validate_feature_value(field, parsed)
            validated[field] = val
        except ValidationError as e:
            errors.append(str(e))
            
    if errors:
        raise ValidationError("\n".join(errors))
        
    return validated

def prompt_validated_feature(field_name: str) -> float:
    """
    Interactive prompt wrapper that repeatedly prompts until valid input is given.
    """
    bounds = FEATURE_BOUNDS[field_name]
    prompt_str = f"Enter {bounds['label']} [{bounds['min']} - {bounds['max']} cm]: "
    
    while True:
        try:
            user_str = input(prompt_str)
            parsed = sanitize_and_parse_float(user_str, bounds['label'])
            val = validate_feature_value(field_name, parsed)
            return val
        except ValidationError as ve:
            print(f"  \033[91mValidation Warning:\033[0m {ve} Please try again.")
        except (KeyboardInterrupt, EOFError):
            raise KeyboardInterrupt()
