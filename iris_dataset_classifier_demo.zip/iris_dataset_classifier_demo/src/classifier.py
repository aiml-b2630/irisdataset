"""
Scikit-Learn Classifier Engine for the Iris Dataset.
Trains model, provides prediction probabilities, and extracts feature importances.
"""

import numpy as np
import pandas as pd
from typing import Dict, Any, Tuple
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, classification_report

class IrisClassifierEngine:
    """
    Core machine learning workflow engine using scikit-learn.
    Trains a Random Forest classifier on the Iris dataset.
    """
    
    SPECIES_NAMES = ["setosa", "versicolor", "virginica"]
    
    def __init__(self, random_state: int = 42):
        self.random_state = random_state
        self.model = RandomForestClassifier(n_estimators=100, random_state=self.random_state)
        self.is_trained = False
        self.accuracy = 0.0
        self.report_dict = {}
        self.feature_names = ["sepal_length", "sepal_width", "petal_length", "petal_width"]
        
        # Train model upon initialization
        self.train_model()

    def train_model(self) -> float:
        """
        Loads the standard Iris dataset, splits into train/test sets, and trains Random Forest.
        """
        iris = load_iris()
        X = pd.DataFrame(iris.data, columns=self.feature_names)
        y = iris.target
        
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=0.2, random_state=self.random_state, stratify=y
        )
        
        self.model.fit(X_train, y_train)
        y_pred = self.model.predict(X_test)
        
        self.accuracy = float(accuracy_score(y_test, y_pred))
        self.report_dict = classification_report(
            y_test, y_pred, target_names=self.SPECIES_NAMES, output_dict=True
        )
        self.is_trained = True
        return self.accuracy

    def predict(self, features: Dict[str, float]) -> Dict[str, Any]:
        """
        Predicts Iris species for a given set of validated feature measurements.
        
        :param features: Dict containing sepal_length, sepal_width, petal_length, petal_width
        :return: Dict with prediction results, probabilities, and confidence score.
        """
        if not self.is_trained:
            self.train_model()
            
        input_data = pd.DataFrame([[
            features["sepal_length"],
            features["sepal_width"],
            features["petal_length"],
            features["petal_width"]
        ]], columns=self.feature_names)
        
        pred_class_idx = self.model.predict(input_data)[0]
        probabilities = self.model.predict_proba(input_data)[0]
        predicted_species = self.SPECIES_NAMES[pred_class_idx]
        confidence = float(probabilities[pred_class_idx])
        
        prob_dict = {
            self.SPECIES_NAMES[i]: float(prob) for i, prob in enumerate(probabilities)
        }
        
        return {
            "predicted_species": predicted_species,
            "confidence": confidence,
            "probabilities": prob_dict,
            "class_index": int(pred_class_idx)
        }

    def get_feature_importances(self) -> Dict[str, float]:
        """
        Returns feature importance scores calculated by the Random Forest model.
        """
        if not self.is_trained:
            self.train_model()
            
        importances = self.model.feature_importances_
        return {
            name: float(imp) for name, imp in zip(self.feature_names, importances)
        }

    def get_model_evaluation_summary(self) -> Dict[str, Any]:
        """
        Returns evaluation performance metrics for the trained model.
        """
        return {
            "model_type": "RandomForestClassifier(n_estimators=100)",
            "test_accuracy": self.accuracy,
            "classification_report": self.report_dict,
            "feature_importances": self.get_feature_importances()
        }
