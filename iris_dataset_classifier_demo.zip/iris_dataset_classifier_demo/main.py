"""
Interactive Terminal Interface for Iris Dataset Classifier Demo.
Provides a clean menu-driven CLI workflow with colorized ANSI formatting.
"""

import os
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from src.classifier import IrisClassifierEngine
from src.storage import StorageEngine
from src.validator import prompt_validated_feature, validate_iris_features, ValidationError
from src.analytics import AnalyticsEngine
from src.visualizer import VisualizerEngine
from src.exporter import SummaryExporter

# ANSI Color formatting helper
class Colors:
    HEADER = '\033[95m'
    BLUE = '\033[94m'
    CYAN = '\033[96m'
    GREEN = '\033[92m'
    WARNING = '\033[93m'
    FAIL = '\033[91m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'
    ENDC = '\033[0m'

def print_banner():
    print(Colors.CYAN + Colors.BOLD + """
==========================================================================
   ____   _         ____         _                       
  / __ \ (_)____   / __ \ _____ (_)____   ____ _ _____   
 / / / // // ___/ / /_/ // ___// // ___/ / __ `// ___/   
/ /_/ // /(__  ) / ____// /   / // /__  / /_/ /(__  )    
\____//_//____/ /_/    /_/   /_/ \___/  \__,_//____/     
   CLASSIFIER DEMO | Scikit-Learn Machine Learning Prototype
==========================================================================
""" + Colors.ENDC)

def display_menu():
    print(Colors.BOLD + "\n--- MAIN NAVIGATION MENU ---" + Colors.ENDC)
    print(f" {Colors.GREEN}1.{Colors.ENDC} Predict Iris Species (Interactive Entry)")
    print(f" {Colors.GREEN}2.{Colors.ENDC} View Prediction Records & Search History")
    print(f" {Colors.GREEN}3.{Colors.ENDC} Executive Analytics & Summary Statistics")
    print(f" {Colors.GREEN}4.{Colors.ENDC} Generate Matplotlib Visual Trend Charts")
    print(f" {Colors.GREEN}5.{Colors.ENDC} Export Multi-Format Reports (Markdown / TXT)")
    print(f" {Colors.GREEN}6.{Colors.ENDC} Evaluate Scikit-Learn Classifier Model")
    print(f" {Colors.GREEN}7.{Colors.ENDC} Exit Application")

def handle_prediction(classifier: IrisClassifierEngine, storage: StorageEngine):
    print(Colors.BOLD + "\n>>> NEW IRIS SPECIES PREDICTION <<<" + Colors.ENDC)
    print("Please enter feature measurements in centimeters:\n")
    
    try:
        sepal_length = prompt_validated_feature("sepal_length")
        sepal_width  = prompt_validated_feature("sepal_width")
        petal_length = prompt_validated_feature("petal_length")
        petal_width  = prompt_validated_feature("petal_width")
        
        notes = input("Enter optional notes or sample label [Press Enter to skip]: ").strip()
        
        features = {
            "sepal_length": sepal_length,
            "sepal_width": sepal_width,
            "petal_length": petal_length,
            "petal_width": petal_width
        }
        
        print("\nProcessing measurements through Scikit-Learn model...")
        result = classifier.predict(features)
        
        # Save record
        saved_rec = storage.save_record(features, result, notes=notes)
        
        print(Colors.GREEN + Colors.BOLD + f"\n[SUCCESS] Prediction Completed & Logged!" + Colors.ENDC)
        print(f"  Record ID         : {Colors.BOLD}{saved_rec['record_id']}{Colors.ENDC}")
        print(f"  Predicted Species : {Colors.CYAN}{Colors.BOLD}{saved_rec['predicted_species'].upper()}{Colors.ENDC}")
        print(f"  Confidence Score  : {Colors.BOLD}{saved_rec['confidence'] * 100:.2f}%{Colors.ENDC}")
        print("  Class Probabilities:")
        for sp, prob in result["probabilities"].items():
            bar = "█" * int(prob * 20)
            print(f"    - {sp.capitalize():<12}: {prob * 100:>5.1f}% [{bar:<20}]")
            
    except KeyboardInterrupt:
        print("\n\nPrediction cancelled by user.")

def handle_view_records(storage: StorageEngine):
    print(Colors.BOLD + "\n>>> PREDICTION RECORDS & SEARCH <<<" + Colors.ENDC)
    query = input("Enter search query or species name (leave empty for all records): ").strip()
    
    records = storage.search_records(query=query)
    if not records:
        print(Colors.WARNING + "No records found matching your query." + Colors.ENDC)
        return
        
    print(f"\nFound {len(records)} record(s):\n")
    print(f"{'ID':<10} | {'Timestamp':<19} | {'Sepal (L/W)':<11} | {'Petal (L/W)':<11} | {'Species':<11} | {'Conf':<6}")
    print("-" * 82)
    for r in records:
        sepal = f"{r['sepal_length']:.1f}/{r['sepal_width']:.1f}"
        petal = f"{r['petal_length']:.1f}/{r['petal_width']:.1f}"
        print(f"{r['record_id']:<10} | {r['timestamp']:<19} | {sepal:<11} | {petal:<11} | {r['predicted_species'].capitalize():<11} | {r['confidence']*100:>5.1f}%")

def handle_analytics(storage: StorageEngine):
    print(Colors.BOLD + "\n>>> EXECUTIVE ANALYTICS SUMMARY <<<" + Colors.ENDC)
    records = storage.load_all_records()
    stats = AnalyticsEngine.compute_summary_statistics(records)
    
    print(f" Total Logged Predictions : {stats['total_records']}")
    print(f" Average Confidence       : {stats['average_confidence']*100:.2f}%")
    print("\n Species Distribution:")
    for sp, cnt in stats['species_counts'].items():
        pct = stats['species_percentages'].get(sp, 0.0)
        print(f"   - {sp.capitalize():<12}: {cnt} ({pct:.1f}%)")
        
    print("\n Feature Averages by Species (cm):")
    for sp, avg in stats.get('species_feature_averages', {}).items():
        if avg['count'] > 0:
            print(f"   [{sp.capitalize()}] Sepal: {avg['sepal_length']}/{avg['sepal_width']} | Petal: {avg['petal_length']}/{avg['petal_width']}")

def handle_plots(storage: StorageEngine, classifier: IrisClassifierEngine):
    print(Colors.BOLD + "\n>>> GENERATING MATPLOTLIB PLOTS <<<" + Colors.ENDC)
    records = storage.load_all_records()
    if not records:
        print(Colors.WARNING + "No records available to plot. Please make some predictions first or run demo.py." + Colors.ENDC)
        return
        
    viz = VisualizerEngine(output_dir="exports")
    f1 = viz.plot_species_distribution(records)
    f2 = viz.plot_petal_scatter(records)
    f3 = viz.plot_feature_importance(classifier.get_feature_importances())
    
    print(Colors.GREEN + f"\n[SUCCESS] Saved 3 visual charts to 'exports/':" + Colors.ENDC)
    print(f"  1. {f1}\n  2. {f2}\n  3. {f3}")

def handle_export(storage: StorageEngine):
    print(Colors.BOLD + "\n>>> EXPORTING MULTI-FORMAT REPORTS <<<" + Colors.ENDC)
    records = storage.load_all_records()
    stats = AnalyticsEngine.compute_summary_statistics(records)
    
    exporter = SummaryExporter(export_dir="exports")
    md_path = exporter.export_markdown_report(stats, records)
    txt_path = exporter.export_audit_log_txt(records)
    
    print(Colors.GREEN + f"\n[SUCCESS] Reports exported successfully:" + Colors.ENDC)
    print(f"  - Markdown Report : {md_path}")
    print(f"  - Audit Log TXT   : {txt_path}")

def handle_evaluate(classifier: IrisClassifierEngine):
    print(Colors.BOLD + "\n>>> SCIKIT-LEARN MODEL EVALUATION <<<" + Colors.ENDC)
    eval_data = classifier.get_model_evaluation_summary()
    print(f" Model Type     : {eval_data['model_type']}")
    print(f" Test Accuracy : {Colors.GREEN}{eval_data['test_accuracy']*100:.2f}%{Colors.ENDC}")
    print("\n Feature Importance Scores:")
    for feat, score in eval_data['feature_importances'].items():
        print(f"   - {feat.replace('_', ' ').title():<15}: {score:.4f}")

def main():
    print_banner()
    classifier = IrisClassifierEngine()
    storage = StorageEngine()
    
    while True:
        display_menu()
        try:
            choice = input(Colors.BOLD + "\nSelect an option [1-7]: " + Colors.ENDC).strip()
            if choice == "1":
                handle_prediction(classifier, storage)
            elif choice == "2":
                handle_view_records(storage)
            elif choice == "3":
                handle_analytics(storage)
            elif choice == "4":
                handle_plots(storage, classifier)
            elif choice == "5":
                handle_export(storage)
            elif choice == "6":
                handle_evaluate(classifier)
            elif choice == "7":
                print(Colors.CYAN + "\nExiting Iris Classifier Demo. Goodbye!" + Colors.ENDC)
                sys.exit(0)
            else:
                print(Colors.FAIL + "Invalid option. Please enter a number between 1 and 7." + Colors.ENDC)
        except (KeyboardInterrupt, EOFError):
            print(Colors.CYAN + "\n\nExiting application." + Colors.ENDC)
            sys.exit(0)

if __name__ == "__main__":
    main()
